package project;

public class MyExpt extends Exception{};